package com.example.khuong.webview;

/**
 * Created by khuong on 10/01/2017.
 */

public class GetJson {
    private String lod;
    private String mo;
    private String mc;
    private String til;
    private String met;
    private String ts;

    public String getlod(){
        return lod;
    }
    public void setlod(String lod){
        this.lod = lod;
    }
    public String getmo(){
        return mo;
    }
    public void setmo(String mo){
        this.mo = mo;
    }
    public String getmc(){
        return mc;
    }
    public void setmc(String mc){
        this.mc = mc;
    }
    public String gettil(){
        return til;
    }
    public void settil(String til){
        this.til = til;
    }
    public String getmet(){
        return met;
    }
    public void setmet(String met){
        this.met = met;
    }
    public String getts(){
        return ts;
    }
    public void setts(String ts){
        this.ts = ts;
    }
}
