package com.example.khuong.webview;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import java.net.URLDecoder;

public class Menu extends AppCompatActivity {

    //private EditText outputText;
    private WebView mywebView;
    private TextView outputText;
    //private EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mywebView = (WebView) findViewById(R.id.webview);
        //outputText=(EditText)this.findViewById(R.id.ouputText);
        outputText=(TextView)this.findViewById(R.id.ouputText);
        WebSettings webSettings = mywebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        mywebView.loadUrl("http://web-smart-traffic.azurewebsites.net/");
//        mywebView.setWebViewClient(new WebViewClient());
        mywebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onLoadResource(WebView view, String url) {
//                System.out.println("xxxxxx "+ url);
                if(url.startsWith("http://dev.virtualearth.net/mapcontrol/logging.ashx")){
//                    System.out.println(url);
                    String getData = url.split("\\?")[1];
//                    System.out.println("data "+getData);
                    String datas[] = getData.split("\\&");
                    String sk = datas[0];
                    String pid = datas[1];
                    String data = datas[2];
//                    System.out.println("sk "+sk);
//                    System.out.println("pid "+pid);
//                    System.out.println("data "+data);
                    String stringJson = data.split("=")[1];
                    stringJson = URLDecoder.decode(stringJson);
//                    StringBuilder builder = new StringBuilder();
//                    try {
//                        JSONObject root = new JSONObject(stringJson);
//                        JSONObject textdata = root.getJSONObject("");
//
//                        JSONArray jsonArray = textdata.getJSONArray("");
//                        for(int i=0;i< jsonArray.length();i++){
//
//                        }
//
//
//                    }catch (JSONException e){
//                        e.printStackTrace();
//                    }
                    System.out.println(stringJson);
                    outputText.setText(stringJson);

                }

            }

        });
//        for(i=0; i< 10; i++){
//            setTiemout({
//                    asdasdasdasd
//            }, 5000*i);
//        }




    }
    public void onBackPressed(){
        if(mywebView.canGoBack()){
            mywebView.goBack();
        }else {
            super.onBackPressed();
        }
    }
}
